Run main.py lang po
